function GetData()
{
  let correo = document.querySelector('#correo').value
  let password = document.querySelector('#password').value
  validateData(correo, password);
}



function validateData(correo, password)
{
  if (correo === "" || password === "")
  {
    console.log('Los campos no pueden estar vacios');
  } else if (correo === "admin" && password === "admin")
  {
    console.log('Los campos coinciden.');
    window.open('../../inicio.html', '_self');
  }else {
    console.log('Correo o Contraña erronea');
  }
}
