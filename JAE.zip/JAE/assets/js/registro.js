function registro() {
  const datosPersonas = {
    nombre: document.getElementById("nombre").value,
    apellido: globalThis.document.getElementById("apellido").value,
    correo: globalThis.document.getElementById("correoUsuario").value,
    telefono: globalThis.document.getElementById("telefonoUsuario").value,
    password: globalThis.document.getElementById("contraseniaUsuario").value,

    //Para la empresa
    nombreEmpresa: globalThis.document.getElementById("nombreEmpresa").value,
    direccionEmpresa:
      globalThis.document.getElementById("direccionEmpresa").value,
    telefonoEmpresa:
      globalThis.document.getElementById("telefonoEmpresa").value,
    correoEmpresa: globalThis.document.getElementById("correoEmpresa").value,
  };

  for (const propety in datosPersonas) {
    console.log(`${propety}: ${datosPersonas[propety]}`);
  }

  // limpiarFormulario();
}

function limpiarFormulario() {
  document.getElementById("nombre").value = "";
  globalThis.document.getElementById("apellido").value = "";
  globalThis.document.getElementById("correoUsuario").value = "";
  globalThis.document.getElementById("telefonoUsuario").value = "";
  globalThis.document.getElementById("contraseniaUsuario").value = "";
}

function validarFormulario() {
  let boton = globalThis.document.getElementById("input__submit");
  if (
    document.getElementById("nombre").value === "" ||
    globalThis.document.getElementById("apellido").value === "" ||
    globalThis.document.getElementById("correoUsuario").value === "" ||
    globalThis.document.getElementById("telefonoUsuario").value === "" ||
    globalThis.document.getElementById("contraseniaUsuario").value === ""
  ) {
    boton.disabled = true;
    console.log("No puedes");
  } else {
    boton.disabled = false;
    console.log("hola");
  }
}
