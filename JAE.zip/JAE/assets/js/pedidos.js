//Declaracion de variables
let blur = document.querySelector("#blur-display");

function MostrarModal() 
{
    let blur = document.querySelector("#blur-display");

    console.log('Has presionado un boton');
    blur.style.visibility = "visible";
}

function CerrarModal()
{
    let blur = document.querySelector("#blur-display");

    // console.log('Has cerrado el modal');
    blur.style.visibility = 'hidden';
}

