//Variables de prueba
let contador = 0;

//Creacion de variable y constantes
const inventario = document.querySelector('.valorInsertado');
const producto = document.querySelector(".cantidadProducto");
const boton = document.querySelector('.btn-enviar');


//Creacion de eventos
boton.addEventListener('click', (e) => {
    e.preventDefault();
    console.log(++contador);
});

//Modificacion del DOM
inventario.innerHTML = "$ 20,255.00";
producto.innerHTML = "762";