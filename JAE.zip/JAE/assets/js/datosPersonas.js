class Personas {
    constructor(nombre, contrasenia) {
        this.nombre = nombre;
        this.contrasenia = contrasenia;
    }
}
