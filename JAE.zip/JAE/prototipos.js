const fecha = {
    dia: new Date().getUTCDate(),
    mes: new Date().getMonth(),
    anio: new Date().getFullYear(),
};

console.log(fecha);